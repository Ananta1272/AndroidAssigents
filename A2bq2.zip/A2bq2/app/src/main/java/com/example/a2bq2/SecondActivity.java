package com.example.a2bq2;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        TextView tvDisplayInfo = findViewById(R.id.tvDisplayInfo);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String firstName = extras.getString("FIRST_NAME", "");
            String middleName = extras.getString("MIDDLE_NAME", "");
            String lastName = extras.getString("LAST_NAME", "");
            String dob = extras.getString("DOB", "");
            String address = extras.getString("ADDRESS", "");
            String email = extras.getString("EMAIL", "");

            String info = getString(R.string.display_format, firstName, middleName, lastName, dob, address, email);

            tvDisplayInfo.setText(info);
        }
    }
}
