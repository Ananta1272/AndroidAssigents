package com.example.a2a1;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        String message = getIntent().getStringExtra("MESSAGE");
        TextView messageTextView = findViewById(R.id.messageTextView);
        if (message != null) {
            messageTextView.setText(message);
        }
    }
}