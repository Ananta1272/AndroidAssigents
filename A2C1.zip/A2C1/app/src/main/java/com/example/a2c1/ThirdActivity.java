package com.example.a2c1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ThirdActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        TextView tvProfile = findViewById(R.id.tvProfile);

        Intent i = getIntent();

        tvProfile.setText(
                "PROFILE INFORMATION\n\n" +
                "Name : " + i.getStringExtra("name") +
                "\nPhone : " + i.getStringExtra("phone") +
                "\nEmail : " + i.getStringExtra("email") +
                "\nCity : " + i.getStringExtra("city")
        );
    }
}