package com.example.a2saq3;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements ItemListFragment.OnItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onItemSelected(String item) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra("selected_item", item);
        startActivity(intent);
    }
}